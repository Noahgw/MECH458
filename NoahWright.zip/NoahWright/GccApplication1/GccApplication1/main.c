/*
 * GccApplication1.c
 *
 * Created: 2023-10-24 11:47:04 AM
 * Author : mech458
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

