/* ##################################################################
# MILESTONE: 1
# PROGRAM: 1
# PROJECT: Lab1 Demo
# GROUP: X
# NAME 1: Noah, Wright, V00913563
# NAME 2: First Name, Last Name, Student ID
# DESC: This program blinks some LEDs like night rider
# DATA
# REVISED ############################################################### */


#include <stdlib.h> // the header of the general-purpose standard library of C programming language
#include <avr/io.h>// the header of I/O port
#include <util/delay_basic.h>

void delaynus();
void delaynms();

/* ################## MAIN ROUTINE ################## */

int main(int argc, char *argv[]){
	
	DDRC = 0b11111111; // Sets all pins on PORTL to output
	PORTC = 0b11000000; 
	delaynms(1000);
	PORTC = 0b01100000;
	delaynms(1000); 
	PORTC = 0b00110000; 
	delaynms(1000); 
	PORTC = 0b00011000; 
	delaynms(1000); 
	PORTC = 0b10100000; 
	delaynms(1000); 
	PORTC = 0b10100000; 
	delaynms(1000); 
	PORTC = 0b10100000; 
	delaynms(1000); 
	PORTC = 0b10100000; 
	
	
	
	return (0); // This line returns a 0 value to the calling program
	// generally means no error was returned
	
}

void delaynus(int n) // delay microsecond
{
	int k;
	for(k=0;k<n;k++)
	_delay_loop_1(1);
}
void delaynms(int n) // delay millisecond
{
	int k;
	for(k=0;k<n;k++)
	delaynus(1000);
}