/* ##################################################################
# MILESTONE: 2
# PROGRAM: 2
# PROJECT: Lab2 Demo
# GROUP: X
# NAME 1: Noah, Wright, V00913563
# NAME 2: First Name, Last Name, Student ID
# DESC: This program blinks some LEDs like night rider
# DATA
# REVISED ############################################################### */


#include <stdlib.h>
#include <avr/io.h>
//#include <lcd.h>
#include <avr/interrupt.h>

void mTimer();

int main(void)
{
   while(1){
   DDRC = 0b11111111; // Sets all pins on PORTL to output
   PORTC = 0b11000000;
   mTimer(5000);
   PORTC = 0b01100000;
   mTimer(1000);
   PORTC = 0b00110000;
   mTimer(1000);
   PORTC = 0b00011000;
   mTimer(1000);
   PORTC = 0b10100000;
   mTimer(1000);
   PORTC = 0b10100000;
   mTimer(1000);
   PORTC = 0b10100000;
   mTimer(1000);
   PORTC = 0b10100000;
   return (0); // This line returns a 0 value to the calling program
			   // generally means no error was returned
   }
}

void mTimer (int count)
{
   /***
      Setup Timer1 as a ms timer
	  Using polling method not Interrupt Driven
   ***/
	  
   int i;

   i = 0;

   TCCR1B |= _BV (CS11);  // Set prescaler (/8) clock 16MHz/8 -> 2MHz
   /* Set the Waveform gen. mode bit description to clear
     on compare mode only */
   TCCR1B |= _BV(WGM12);

   /* Set output compare register for 2000 cycles, 1ms */
   OCR1A = 0x07D0;
 
   /* Initialize Timer1 to zero */
   TCNT1 = 0x0000;

   /* Enable the output compare interrupt */
   //TIMSK1 |= _BV(OCIE1A);  //remove if global interrups is set (sei())

   /* Clear the Timer1 interrupt flag and begin timing */
   TIFR1 |= _BV(OCF1A);

   /* Poll the timer to determine when the timer has reached 1ms */
   while (i < count)
   {
      while ((TIFR1 & 0x02) != 0x02);
	
	   /* Clear the interrupt flag by WRITING a ONE to the bit */
	   TIFR1 |= _BV(OCF1A);
	   i++;
   } /* while */
   TCCR1B &= ~_BV (CS11);  //  disable prescalar, no Clock
   return;
}  /* mTimer */

