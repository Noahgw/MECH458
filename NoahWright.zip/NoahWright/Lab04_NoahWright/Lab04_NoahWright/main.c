
/* Solution Set for Lab4 */

/*

# MILESTONE: 4

# PROGRAM: 4

# PROJECT: Lab4

# GROUP: X

# NAME 1: Noah, Wright, V00913563

# NAME 2: Caleb, McGee, V00

# DESC:

# DATA

*/

 

/* include libraries */

#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>

 

/* global variables */
int currentStep = 0;

/* Subroutines*/
void mTimer();
void pwmGeneration();
void rotateDevice(int rotDirection, int currentStep, int numSteps);
void initializeStep();
int debug(char intput);

 

int main(){
	CLKPR = 0x80;
	CLKPR = 0x01;
	DDRA = 0b11111111; // Sets all pins on PORTC to output
	pwmGeneration();
	
	while(1){
	
	//initializeStep(); //Start motor
	
		/*
		rotateDevice(1, currentStep, 17); //Rotate 30 degrees CW
		mTimer(2000);
		rotateDevice(1, currentStep, 33); //Rotate 60 Degrees CW
		mTimer(2000);
		rotateDevice(1, currentStep, 100); //Rotate 180 Degrees CW
		mTimer(2000);

		rotateDevice(0, currentStep, 17); //Rotate 30 degrees CCW
		mTimer(2000);
		rotateDevice(0, currentStep, 33); //Rotate 60 Degrees CCW
		mTimer(2000);
		rotateDevice(0, currentStep, 100); //Rotate 180 Degrees CCW
		mTimer(2000);*/
		
	}
}

/* main */

/**************************************************************************************/

/***************************** SUBROUTINES ********************************************/

/**************************************************************************************/

void pwmGeneration(){
	   DDRB = 0b10000000;
	   
       
       TCCR0A |= _BV(WGM00); // Update OCRx at TOP
	   TCCR0A |= _BV(WGM01); // TOP set to 0xFF


       TIMSK0 |= _BV(OCIE0A); //Timer/Counter Interrupt Mask Register

       TCCR0A |= _BV(COM0A1); //Clear OC0A on Compare Match, set OC0A at BOTTOM
	   
	   TCCR0B |= _BV(CS01);
	   	   
       OCR0A = 0x80; //This is the point the signal should reset

       //OC0A Shares PORT B7
}

void initializeStep(){

       int stepCounter = 0;
       int finalStep = 90;
       int step = 0;
	   
       while(stepCounter < finalStep){
			
			step++; //Advance to next step
			if (step > 3){
				step = 0;
			}
              switch(step){

                     case (0x00):
						 PORTA = 0b00000011;
						 break;
						 
                     case (0x01):
						 PORTA = 0b00011000;
						 break;
						 
                     case (0x02):
						 PORTA = 0b00000101;
						 break;
						 
                     case (0x03):
						 PORTA = 0b00101000;
						 break;
						 
                     default:
						 break;
			  }
			  
			  mTimer(20);
              stepCounter++; //increment the counter by 1
              
       }

       currentStep = step; //initialize current step
	   mTimer(5000);

}

 

void rotateDevice(int rotDirection, int currentStep, int numSteps){

       int stepsCompleted = 0;

       if (rotDirection == 1){ //Clockwise Direction

              while(stepsCompleted < numSteps){
					
					 currentStep++; //Advance to next step
					 if (currentStep > 3){
						 currentStep = 0;
					 }
                     switch(currentStep){ //output required signal based off the step number

                           case (0x00):
                                  PORTA = 0b00000011;
                                  break;
                           case (0x01):
                                  PORTA = 0b00011000;                       
                                  break;
                           case (0x02):
                                  PORTA = 0b00000101;                       
                                  break;
                           case (0x03):
                                  PORTA = 0b00101000;                
                                  break;
                           default:
                                  break;

                     }
					 
					 mTimer(20);
             
                     stepsCompleted++; //Advance the step completed by 1

                     
              }

       } else if (rotDirection == 0){ //Counter Clockwise Direction
				
              while(stepsCompleted < numSteps){
				  currentStep--; //Advance to next step
				  if (currentStep < 0){
					  currentStep = 3;
				  }
                     switch(currentStep){
						 
                           case (0x00):
							  PORTA = 0b00000011;
							  break;
                           case (0x01):
							  PORTA = 0b00011000;
							  break;
                           case (0x02):
							  PORTA = 0b00000101;
                              break;
                           case (0x03):
                              PORTA = 0b00101000;
                              break;
                           default:
                              break;

                     }
					 
					 mTimer(20);
                     
                     stepsCompleted++; //Advance the step completed by 1
					 
              }
       } 	   
}

 

void mTimer (int count)

{

   /***

      Setup Timer1 as a ms timer

Using polling method not Interrupt Driven

   ***/


   int i;

 

   i = 0;

 

   TCCR1B |= _BV (CS11);  // Set prescaler (/8) clock 16MHz/8 -> 2MHz

   /* Set the Waveform gen. mode bit description to clear

     on compare mode only */

   TCCR1B |= _BV(WGM12);

 

   /* Set output compare register for 2000 cycles, 1ms */

   OCR1A = 0x07D0;


   /* Initialize Timer1 to zero */

   TCNT1 = 0x0000;

 

   /* Enable the output compare interrupt */

   //TIMSK1 |= _BV(OCIE1A);  //remove if global interrups is set (sei())

 

   /* Clear the Timer1 interrupt flag and begin timing */

   TIFR1 |= _BV(OCF1A);

 

   /* Poll the timer to determine when the timer has reached 1ms */

   while (i < count)

   {

      while ((TIFR1 & 0x02) != 0x02);

  /* Clear the interrupt flag by WRITING a ONE to the bit */

  TIFR1 |= _BV(OCF1A);

  i++;

   } /* while */

   TCCR1B &= ~_BV (CS11);  //  disable prescalar, no Clock

   return;

}  /* mTimer */