/*
 * LCDTroubleShoot.c
 *
 * Created: 2023-11-20 3:45:14 PM
 * Author : mech458
 */ 

#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdlib.h>
#include "lcd.h"
#include "LCD.c"
#include "myutils.h"

void mTimer();

int main(void)
{
	InitLCD(LS_BLINK|LS_ULINE);
    /* Replace with your application code */
    while (1) 
    {
		LCDWriteStringXY(0,0,"LCD is Working");
		mTimer(20);
    }
}

void mTimer (int count)

{

   /***

      Setup Timer1 as a ms timer

Using polling method not Interrupt Driven

   ***/

   int i;
   i = 0;
   
   TCCR1B |= _BV(CS11);  // Set prescaler (/8) clock 16MHz/8 -> 2MHz
   /* Set the Waveform gen. mode bit description to clear
     on compare mode only */
   TCCR1B |= _BV(WGM12);

   /* Set output compare register for 2000 cycles, 1ms */
   OCR1A = 0x07D0;

   /* Initialize Timer1 to zero */
   TCNT1 = 0x0000;
   /* Enable the output compare interrupt */

   //TIMSK1 |= _BV(OCIE1A);  //remove if global interrups is set (sei())

   /* Clear the Timer1 interrupt flag and begin timing */
   TIFR1 |= _BV(OCF1A);

   /* Poll the timer to determine when the timer has reached 1ms */
   while (i < count)
   {
      while ((TIFR1 & 0x02) != 0x02);
  /* Clear the interrupt flag by WRITING a ONE to the bit */
  TIFR1 |= _BV(OCF1A);
  i++;
   } /* while */
   TCCR1B &= ~_BV (CS11);  // disable prescalar, no Clock
   return;
}  /* mTimer */
