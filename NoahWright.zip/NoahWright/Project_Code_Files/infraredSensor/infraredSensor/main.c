
/* Solution Set for Lab4 */
/*
# MILESTONE: 4
# PROGRAM: 4
# PROJECT: Lab4
# GROUP: X
# NAME 1: Noah, Wright, V00913563
# NAME 2: Caleb, McGee, V00
# DESC:
# DATA

*/

#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdlib.h>
#include "lcd.h"
#include "LCD.c"
#include "myutils.h"

void mTimer();
void pwmGeneration();
void initializeInterrupts();

// define the global variables that can be used in every function ==========
int currentStep = 0;
volatile unsigned char ADC_result;
volatile unsigned int ADC_result_flag;
volatile unsigned int programRunning = 1;
int directionMotor = 0; // 0 CW 1 CCW



int main()
{

	CLKPR = 0x08;
	CLKPR = 0x01; //8 MHz

	pwmGeneration();
	initializeInterrupts();

	// set the PORTC as output to display the ADC result ==================	
	DDRC = 0xff;
	
	// set the PORTB as an output to control DC Motor Driver
	DDRB = 0xff;
	PORTB = 0xff;
	
	//Initialize LCD module
	InitLCD(LS_BLINK|LS_ULINE);

	//Clear the screen
	LCDClear();
	
	// initialize the ADC ==========
	ADCSRA |= _BV(ADSC);
	
	LCDWriteStringXY(0,0,"Program Starting");
	mTimer(500);
	LCDClear();
	
	while (programRunning)
	{ 
		if (ADC_result_flag)
		{
			OCR0A=ADC_result;
			LCDWriteStringXY(0,0, "ADC Val:")
			LCDWriteIntXY(9,0,ADC_result, 3); // Print the result on the LCD
			mTimer(20);
			
			ADC_result_flag = 0x00; // Reset the result flag
			
			// initialize the ADC ==========
			ADCSRA |= _BV(ADSC);
		}
	}
	
} // end main

// Kill Switch 
ISR(INT0_vect)
{ // When a rising edge is detected on B1, we need to KILL PROGRAM ==========
	
	//Fix Mechanical Debounce

	while((PIND & 0b00000001) == 0b00000000);
	mTimer(20);
	
	//Stop program
	OCR0A = 0x00;
	PORTB = 0b00001111;
	programRunning = 0;
		
	LCDClear();
	mTimer(20);
	LCDWriteStringXY(0,0, "Terminated");
	
	while((PIND & 0b00000001) == 0b00000001);
	mTimer(200);
}

ISR(INT1_vect)
{ // When a rising edge is detected on D1 =====================

}

// sensor switch: Active LOW starts AD converstion =======
ISR(INT2_vect)
{ // When a falling edge is detected D2,  =====================

}

ISR(INT3_vect)
{ // When a falling edge is detected on D3,  =====================

	
}



// the interrupt will be trigured if the ADC is done ========================
ISR(ADC_vect)
{
		
	ADC_result = ADCH;  // Set ADC result as the value in the ADCH register
	ADC_result_flag = 1;  // Flag letting program know the ADC has new result
	
	
}

void initializeInterrupts(){
	cli(); // disable all of the interrupt ==========================
	// config the external interrupt ======================================
	EIMSK |= (_BV(INT0)); // enable INT0 (Kill Switch)
	EICRA |= (_BV(ISC01) | _BV(ISC00)); // rising edge interrupt
	
	EIMSK |= (_BV(INT1)); // enable INT1 
	EICRA |= (_BV(ISC11) | _BV(ISC10)); // rising edge interrupt
	
	EIMSK |= (_BV(INT2)); // enable INT2
	EICRA |= (_BV(ISC21)); // falling edge interrupt
	
	EIMSK |= (_BV(INT3)); // enable INT3
	EICRA |= (_BV(ISC31) | _BV(ISC30)); // rising edge interrupt

	
	
	// config ADC =========================================================
	// by default, the ADC input (analog input is set to be ADC0 / PORTF0
	ADCSRA |= _BV(ADEN); // enable ADC
	ADCSRA |= _BV(ADIE); // enable interrupt of ADC
	ADMUX |= _BV(ADLAR) | _BV(REFS0); // Left adjusts the result, and selects
	// the voltage reference as AVCC with
	// external capacitor at AREF pin
	
	// sets the Global Enable for all interrupts ==========================
	sei();
	
}

void pwmGeneration(){

	TCCR0A |= _BV(WGM01); // TOP set to 0xFF
	TCCR0A |= _BV(WGM00); // Update OCRx at TOP
	TCCR0B &= ~_BV(WGM02); // Set TOV flag at MAX

	//TIMSK0 |= _BV(OCIE0A); //Timer/Counter Interrupt Mask Register

	TCCR0A |= _BV(COM0A1); //Clear OC0A on Compare Match, set OC0A at BOTTOM
	TCCR0A &= ~_BV(COM0A0);
	
	TCCR0B |= _BV(CS00);
	TCCR0B |= _BV(CS02);

	OCR0A = 0x80; //This is the point the signal should reset

	//OC0A Shares PORT B
}

void mTimer (int count)

{

   /***

      Setup Timer1 as a ms timer

Using polling method not Interrupt Driven

   ***/

   int i;
   i = 0;
   
   TCCR1B |= _BV(CS11);  // Set prescaler (/8) clock 16MHz/8 -> 2MHz
   /* Set the Waveform gen. mode bit description to clear
     on compare mode only */
   TCCR1B |= _BV(WGM12);

   /* Set output compare register for 2000 cycles, 1ms */
   OCR1A = 0x07D0;

   /* Initialize Timer1 to zero */
   TCNT1 = 0x0000;
   /* Enable the output compare interrupt */

   //TIMSK1 |= _BV(OCIE1A);  //remove if global interrups is set (sei())

   /* Clear the Timer1 interrupt flag and begin timing */
   TIFR1 |= _BV(OCF1A);

   /* Poll the timer to determine when the timer has reached 1ms */
   while (i < count)
   {
      while ((TIFR1 & 0x02) != 0x02);
  /* Clear the interrupt flag by WRITING a ONE to the bit */
  TIFR1 |= _BV(OCF1A);
  i++;
   } /* while */
   TCCR1B &= ~_BV (CS11);  // disable prescalar, no Clock
   return;
}  /* mTimer */