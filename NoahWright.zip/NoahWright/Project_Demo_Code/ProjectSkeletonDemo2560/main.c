// READ EVERY SINGLE WORD IN THIS PIECE OF CODE...IF YOU DON'T YOU WILL NOT UNDERSTAND THIS!!!!!!!
// READ EVERY SINGLE WORD IN THIS PIECE OF CODE...IF YOU DON'T YOU WILL NOT UNDERSTAND THIS!!!!!!!
// READ EVERY SINGLE WORD IN THIS PIECE OF CODE...IF YOU DON'T YOU WILL NOT UNDERSTAND THIS!!!!!!!
// READ EVERY SINGLE WORD IN THIS PIECE OF CODE...IF YOU DON'T YOU WILL NOT UNDERSTAND THIS!!!!!!!
// READ EVERY SINGLE WORD IN THIS PIECE OF CODE...IF YOU DON'T YOU WILL NOT UNDERSTAND THIS!!!!!!!
// READ EVERY SINGLE WORD IN THIS PIECE OF CODE...IF YOU DON'T YOU WILL NOT UNDERSTAND THIS!!!!!!!

// Open up the document in START -> WinAVR -> AVR LibC -> User Manual -> avr/interrupt.h
// Chapter 15, in Full Manual... THIS HAS A LOT OF IMPORTANT INFO...I have mentioned this at least 3 times!!!

// For those that are still having major problems, I've seen about 1/3 of the class with major problems in
// code structure. If you are still having major problems with your code, it's time to do a VERY quick overhaul.
// I've provided a skeleton structure with an example using two input capture interrupts on PORTDA0 and A3
// Please try this in the debugger.

// Create a watch variable on STATE. To do this right click on the variable STATE and then
// Add Watch 'STATE'. You can see how the variable changes as you click on PINDA0 or PINDA3. Note that the interrupt
// catches a rising edge. You modify this to suit your needs.

#include <avr/interrupt.h>
#include <avr/io.h>
#include "lcd.h"
#include "LCD.c"
#include "myutils.h"

// Global Variable
volatile char STATE;
volatile unsigned char ADC_result;
volatile unsigned int ADC_result_flag;

// Functions List
void mTimer();
void initializeInterrupts();


int main(int argc, char *argv[]){
	
	CLKPR = 0x80;
	CLKPR = 0x01;		//  sets system clock to 8MHz

	STATE = 0;
	
	initializeInterrupts();
	
	//Initialize LCD module
	InitLCD(LS_BLINK|LS_ULINE);
	
	LCDWriteStringXY(0,0,"Program Starting");
	mTimer(500);
	
	LCDClear();
	
	goto POLLING_STAGE;

	// POLLING STATE
	POLLING_STAGE:
	LCDClear();
	LCDWriteStringXY(0,0,"Polling Stage");
	mTimer(50);
	
	switch(STATE){
		case (0) :
		goto POLLING_STAGE;
		break;	//not needed but syntax is correct
		case (1) :
		goto MAGNETIC_STAGE;
		break;
		case (2) :
		goto REFLECTIVE_STAGE;
		break;
		case (3) :
		goto BUCKET_STAGE;
		break;
		case (5) :
		goto END;
		default :
		goto POLLING_STAGE;
	}//switch STATE
	

	MAGNETIC_STAGE:
	// Do whatever is necessary HERE
	LCDClear();
	mTimer(20);
	LCDWriteStringXY(0,0,"Magenetic Stage");
	mTimer(2000);
	//Reset the state variable
	STATE = 0;
	goto POLLING_STAGE;

	REFLECTIVE_STAGE:
	// Do whatever is necessary HERE
	//PORTC = 0x04; // Just output pretty lights know you made it here
	if(ADC_result_flag){
		LCDClear();
		mTimer(20);
		LCDWriteStringXY(0,0,"Reflective Stage");
		mTimer(20);
		LCDWriteStringXY(0,1,"ADC:");
		LCDWriteIntXY(5,1,ADC_result,5);
		mTimer(2000);
		
		ADC_result_flag=0;
	}
	//Reset the state variable
	STATE = 0;
	goto POLLING_STAGE;
	
	BUCKET_STAGE:
	LCDClear();
	mTimer(20);
	LCDWriteStringXY(0,0,"Bucket Stage");
	mTimer(2000);
	//Reset the state variable
	STATE = 0;
	goto POLLING_STAGE;
	
	END:
	// The closing STATE ... how would you get here?
		LCDClear();
		mTimer(20);
		LCDWriteStringXY(0,0,"Terminated");
		mTimer(2000);
	// Stop everything here...'MAKE SAFE'
	return(0);

}

/* Set up the External Interrupt 2 Vector */
ISR(INT2_vect){
	/* Toggle PORTC bit 2 */
	STATE = 2;
	// initialize the ADC ==========
	ADCSRA |= _BV(ADSC);
}

ISR(INT3_vect){
	/* Toggle PORTC bit 3 */
	STATE = 3;
}


// the interrupt will be trigured if the ADC is done ========================
ISR(ADC_vect)
{
	
	ADC_result = (ADCL << 8) +| ADCH ;  // Set ADC result as the value in the ADCH register
	ADC_result_flag = 1;  // Flag letting program know the ADC has new result
	
	
}

// If an unexpected interrupt occurs (interrupt is enabled and no handler is installed,
// which usually indicates a bug), then the default action is to reset the device by jumping
// to the reset vector. You can override this by supplying a function named BADISR_vect which
// should be defined with ISR() as such. (The name BADISR_vect is actually an alias for __vector_default.
// The latter must be used inside assembly code in case <avr/interrupt.h> is not included.
ISR(BADISR_vect)
{
		LCDClear();
		mTimer(20);
		LCDWriteStringXY(0,0,"PROBLEM");
		mTimer(2000);
}

void initializeInterrupts(){
	cli();		// Disables all interrupts
	
	DDRD = 0b11110000;	// Going to set up INT2 & INT3 on PORTD
	DDRC = 0xFF;		// just use as a display


	// Set up the Interrupt 0,3 options
	//External Interrupt Control Register A - EICRA (pg 110 and under the EXT_INT tab to the right
	// Set Interrupt sense control to catch a rising edge
	EICRA |= _BV(ISC21) | _BV(ISC20);
	EICRA |= _BV(ISC31);

	//	EICRA &= ~_BV(ISC21) & ~_BV(ISC20); /* These lines would undo the above two lines */
	//	EICRA &= ~_BV(ISC31) & ~_BV(ISC30); /* Nice little trick */


	// See page 112 - EIFR External Interrupt Flags...notice how they reset on their own in 'C'...not in assembly
	EIMSK |= 0x0C;
	
	// config ADC =========================================================
	// by default, the ADC input (analog input is set to be ADC0 / PORTF0
	ADCSRA |= _BV(ADEN); // enable ADC
	ADCSRA |= _BV(ADIE); // enable interrupt of ADC
	ADMUX |= _BV(ADLAR) | _BV(REFS0); // Left adjusts the result, and selects
	// the voltage reference as AVCC with
	// external capacitor at AREF pin

	// Enable all interrupts
	sei();	// Note this sets the Global Enable for all interrupts
}

void mTimer (int count)

{

   /***

      Setup Timer1 as a ms timer

Using polling method not Interrupt Driven

   ***/

   int i;
   i = 0;
   
   TCCR1B |= _BV(CS11);  // Set prescaler (/8) clock 16MHz/8 -> 2MHz
   /* Set the Waveform gen. mode bit description to clear
     on compare mode only */
   TCCR1B |= _BV(WGM12);

   /* Set output compare register for 2000 cycles, 1ms */
   OCR1A = 0x07D0;

   /* Initialize Timer1 to zero */
   TCNT1 = 0x0000;
   /* Enable the output compare interrupt */

   //TIMSK1 |= _BV(OCIE1A);  //remove if global interrups is set (sei())

   /* Clear the Timer1 interrupt flag and begin timing */
   TIFR1 |= _BV(OCF1A);

   /* Poll the timer to determine when the timer has reached 1ms */
   while (i < count)
   {
      while ((TIFR1 & 0x02) != 0x02);
  /* Clear the interrupt flag by WRITING a ONE to the bit */
  TIFR1 |= _BV(OCF1A);
  i++;
   } /* while */
   TCCR1B &= ~_BV (CS11);  // disable prescalar, no Clock
   return;
}  /* mTimer */
